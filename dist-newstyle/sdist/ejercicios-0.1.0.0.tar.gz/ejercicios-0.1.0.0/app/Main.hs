import Graphics.Gloss

windowWidth :: Int
windowWidth = 400

windowHeight :: Int
windowHeight = 400

pixelSize :: Float
pixelSize = 20

azul :: Color
azul = rgbToColor (2, 101, 204)

azulClaro :: Color
azulClaro = rgbToColor (44,204,239)

negro :: Color
negro = rgbToColor (0,0,0)

piel :: Color
piel = rgbToColor (253,195,153)

blanco :: Color
blanco = rgbToColor (255,255,255)

rgbToColor :: (Int, Int, Int) -> Color
rgbToColor (r, g, b) = makeColor (r' / 255) (g' / 255) (b' / 255) 1.0
    where
        r' = fromIntegral r
        g' = fromIntegral g
        b' = fromIntegral b

main :: IO ()
main = display (InWindow "Pixel" (windowWidth, windowHeight) (10, 10)) white picture

picture :: Picture
picture = pictures [
    createPixel (0, 100) negro (pixelSize * 3, pixelSize),
    createPixel (-40, 80) negro (pixelSize * 3, pixelSize),
    createPixel (10, 80) azulClaro (pixelSize * 2, pixelSize),
    createPixel (40, 80) negro (pixelSize , pixelSize),
    createPixel (-80, 60) negro (pixelSize , pixelSize),
    createPixel (-40, 60) azul (pixelSize * 3, pixelSize),
    createPixel (0, 60) negro (pixelSize , pixelSize),
    createPixel (30, 60) azulClaro (pixelSize * 2, pixelSize),
    createPixel (60, 60) negro (pixelSize, pixelSize),
    createPixel (-100, 40) negro (pixelSize , pixelSize),
    createPixel (-40, 40) azul (pixelSize * 5, pixelSize),
    createPixel (50, 40) negro (pixelSize * 4, pixelSize),
    createPixel (-100, 20) negro (pixelSize , pixelSize),
    createPixel (-40, 20) azul (pixelSize * 5, pixelSize),
    createPixel (20, 20) negro (pixelSize, pixelSize),
    createPixel (50, 20) azulClaro (pixelSize * 2, pixelSize),
    createPixel (80, 20) azul (pixelSize, pixelSize),
    createPixel (100, 20) negro (pixelSize, pixelSize),
    createPixel (-120, 0) negro (pixelSize , pixelSize),
    createPixel (-100, 0) azulClaro (pixelSize , pixelSize),
    createPixel (-30, 0) azul (pixelSize * 6, pixelSize),
    createPixel (50, 0) negro (pixelSize * 2, pixelSize),
    createPixel (80, 0) azul (pixelSize, pixelSize),
    createPixel (100, 0) negro (pixelSize, pixelSize),
    createPixel (-120, -20) negro (pixelSize , pixelSize),
    createPixel (-100, -20) azulClaro (pixelSize , pixelSize),
    createPixel (-70, -20) azul (pixelSize * 2, pixelSize),
    createPixel (-40, -20) piel (pixelSize , pixelSize),
    createPixel (0, -20) blanco (pixelSize * 3, pixelSize),
    createPixel (50, -20) azul (pixelSize * 2, pixelSize),
    createPixel (80, -20) blanco (pixelSize, pixelSize),
    createPixel (100, -20) negro (pixelSize, pixelSize),
    createPixel (-120, -40) negro (pixelSize , pixelSize),
    createPixel (-100, -40) azulClaro (pixelSize , pixelSize),
    createPixel (-80, -40) azul (pixelSize , pixelSize),
    createPixel (-60, -40) piel (pixelSize , pixelSize),
    createPixel (-30, -40) blanco (pixelSize * 2, pixelSize),
    createPixel (10, -40) negro (pixelSize * 2, pixelSize),
    createPixel (40, -40) piel (pixelSize, pixelSize),
    createPixel (60, -40) negro(pixelSize, pixelSize),
    createPixel (80, -40) blanco(pixelSize, pixelSize),
    createPixel (100, -40) negro(pixelSize, pixelSize),
    createPixel (-100, -60) negro (pixelSize , pixelSize),
    createPixel (-80, -60) azul (pixelSize , pixelSize),
    createPixel (-60, -60) piel (pixelSize , pixelSize),
    createPixel (-30, -60) blanco (pixelSize * 2, pixelSize),
    createPixel (10, -60) negro (pixelSize * 2, pixelSize),
    createPixel (40, -60) piel (pixelSize, pixelSize),
    createPixel (60, -60) negro(pixelSize, pixelSize),
    createPixel (80, -60) blanco(pixelSize, pixelSize),
    createPixel (100, -60) negro(pixelSize, pixelSize),
    createPixel (-110, -80) negro (pixelSize * 2, pixelSize),
    createPixel (-80, -80) azul (pixelSize , pixelSize),
    createPixel (-50, -80) piel (pixelSize * 2, pixelSize),
    createPixel (0, -80) blanco (pixelSize * 3, pixelSize),
    createPixel (40, -80) piel (pixelSize , pixelSize),
    createPixel (60, -80) blanco (pixelSize , pixelSize),
    createPixel (80, -80) piel (pixelSize , pixelSize),
    createPixel (100, -80) negro (pixelSize , pixelSize),
    createPixel (-140, -100) negro (pixelSize * 2, pixelSize),
    createPixel (-100, -100) azulClaro (pixelSize * 2, pixelSize)
    ]

createPixel :: (Float, Float) -> Color -> (Float, Float) -> Picture
createPixel (x, y) col (width, height) = translate x y $ color col $ rectangleSolid width height